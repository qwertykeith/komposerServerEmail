var cred = require('./lib/cred')
var aws = require('aws-sdk');
var ses = new aws.SES();

module.exports.send = (event, context, callback) => {

  var eParams = {
    Destination: {
      ToAddresses: ["qwertykeith@gmail.com"]
    },
    Message: {
      Body: {
        Text: {
          Data: JSON.stringify(event)
        }
      },
      Subject: {
        Data: "Ses Test Email"
      }
    },
    Source: "qwertykeith@gmail.com"
  };

  console.log('===SENDING EMAIL===');
  var email = ses.sendEmail(eParams, function (err, data) {
    if (err) {
      console.log(err);
      callback(err);
    } else {
      console.log("===EMAIL SENT===");
      //      console.log(data);
    }

    const response = {
      statusCode: 200,
      body: JSON.stringify({
        message: 'HowdeeeeDoooooo!',
      }),
    };


    callback(null, response);
  });
  console.log("EMAIL CODE END");
  console.log('EMAIL: ', email);
};